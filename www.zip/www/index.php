<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
        <title>Dog Years Calculator</title>
    </head>
    <body>
        <script type="text/javascript" src="cordova.js"></script>
        <h1>Dog Years Calculator</h1>
        <label for="dogAge">Dog Age in Human Ycscvzdvzzsears:</label>
        
    </body>
</html>
